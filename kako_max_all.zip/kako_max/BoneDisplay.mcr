macroscript BoneDisplay
category:"kako"
(
hideByCategory.bones = not hideByCategory.bones
)