macroScript APRV category:"kako" tooltip:"kahraman" buttontext:"kako_pre"
(

global APRV_txtcolor
global vp_info

APRV_txtcolor = (color 200 200 200)

fn calc_fpsratio =
(
ratio = (framerate*100)/30
cur_ratio = ((ratio as string)+"%"+ " - ")
)

fn read_fps =
(
cur_fps = ((framerate as string)+" fps"+ " - ")
cur_fps
)
fn read_framenumber =
(
t = slidertime
cur_frame = (((t.frame as integer) as string) + " - ")
cur_frame
)
fn read_camera =
(
cur_cam_name = ""
	if (viewport.getType() as string) == "view_camera" then 
		(
		cam = viewport.getcamera()
		cur_cam_name = ((cam.name as string) + " - ")
		)
cur_cam_name
)
fn read_filename = 
(
cur_filename = ((maxfilename as string) + " - ")
)

fn vp_info =
(
maxfname = read_filename()
cam_name = read_camera()
frame = read_framenumber()
fps = read_fps()
fpsratio = calc_fpsratio()


makinaadi = sysInfo.username
--write_string = (maxfname + cam_name + frame + fps + fpsratio + makinaadi)
write_string = (maxfname + cam_name + frame + fps + makinaadi)
	
y = (gw.getwinsizey() - 25)
x = (write_string.count*6)


gw.setTransform (matrix3 1)
gw.clearScreen(box2 0 y x 25) useBkg:true
gw.enlargeUpdateRect (box2 0 y x 25)
gw.htext [3,3,100] write_string color:APRV_txtcolor
	
gw.updatescreen()
)

	
	


registerRedrawViewsCallback vp_info 
max preview
unregisterRedrawViewsCallback vp_info

maxyol=maxfilepath+maxfilename
dosyaadi=getFilenameFile maxyol
deletefile ((getDir #preview)+ "\\"+dosyaadi+"_kahraman"+".avi")
copyfile  ((getDir #preview)+ "\\_scene.avi") ((getDir #preview)+ "\\"+dosyaadi+"_kahraman"+".avi")

)